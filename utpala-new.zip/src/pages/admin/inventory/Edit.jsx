import React from 'react'

function Inventory_Edit() {
    return (
        <div>Inventory_Edit</div>
    )
}

export default Inventory_Edit