export default {
    Data: [
      {
        id: 1,
        OrderId: "#RX-23-001",
        Patient: "Akshay",
        Doctor: "25000",
        Dept: "OPD",
        Status: "Pending",
      },
      {
        id: 1,
        OrderId: "#RX-23-002",
        Patient: "Deepak",
        Doctor: "Dr. Sameer",
        Dept: "IPD",
        Status: "Completed",
      },
    ],
  };
  