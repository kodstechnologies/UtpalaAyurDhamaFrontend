export default {
    Data: [
      {
        id: 1,
        Type: "Equipment",
        Quantity: "500",
        UnitCost: "50",
        TotalCost: "25000",
        AddedBy: "Dr. Sameer",
        Date: "28-05-25",
        Supplier: "Rajesh",
        Expiry: "28-05-26",
        Notes: "Note note",
      },
    ],
  };
  