export default {
  Data: [
    {
      id: 1,
      ItemCode: "#IT002",
      Name: "Surgical Gloves",
      Type: "Equipment",
      Quantity: "2130",
      Status: "Good Stock",
    },
    {
      id: 2,
      ItemCode: "#IT003",
      Name: "Face Masks",
      Type: "Drug",
      Quantity: "450",
      Status: "Low Stock",
    },
    {
      id: 3,
      ItemCode: "#IT004",
      Name: "Cotton Swabs",
      Type: "Equipment",
      Quantity: "2810",
      Status: "Good Stock",
    },
  ],
};
