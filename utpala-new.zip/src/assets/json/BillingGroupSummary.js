export default {
  Data: [
    {
      id: "1",
      FeesType: "Admission Fee",
      Amount: "1000",
    },
    {
        id: "2",
        FeesType: "Room Charge",
        Amount: "5000",
      },
  ],
};
