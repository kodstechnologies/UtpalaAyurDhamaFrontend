import { blogimg10, blogimg12, blogimg2, blogimg4, blogimg6, blogimg8 } from "../../components/imagepath";



export default {
  Data: [
      {
        id:"1",
        Img:blogimg2,
        Name: "Andrea Lalema",
        Department: "Otolaryngology",
        Specialization: "Infertility",
        Degree: "MBBS, MS",
        Mobile: "+1 23 456890",
        Email: "example@email.com",
        JoiningDate: "01.10.2022",
        FIELD9: ""
      },
      {
        id:"2",
        Img:blogimg4,
        Name: "Dr.Smith Bruklin",
        Department: "Urology",
        Specialization: "Prostate",
        Degree: "MBBS, MS",
        Mobile: "+1 23 456890",
        Email: "example@email.com",
        JoiningDate: "01.10.2022",
        FIELD9: ""
      },
      {
        id:"3",
        Img:blogimg6,
        Name: "Dr.William Stephin",
        Department: "Radiology",
        Specialization: "Cancer",
        Degree: "MBBS, MS",
        Mobile: "+1 23 456890",
        Email: "example@email.com",
        JoiningDate: "01.10.2022",
        FIELD9: ""
      },
      {
        id:"4",
        Img:blogimg12,
        Name: "Bernardo James",
        Department: "Dentist",
        Specialization: "Prostate",
        Degree: "MBBS, MS",
        Mobile: "+1 23 456890",
        Email: "example@email.com",
        JoiningDate: "01.10.2022",
        FIELD9: ""
      },
      {
        id:"5",
        Img:blogimg10,
        Name: "Cristina Groves",
        Department: "Gynocolgy",
        Specialization: "Prostate",
        Degree: "MBBS, MS",
        Mobile: "+1 23 456890",
        Email: "example@email.com",
        JoiningDate: "01.10.2022",
        FIELD9: ""
      },
      {
        id:"6",
        Img:blogimg8,
        Name: "Mark Hay Smith",
        Department: "Gynocolgy",
        Specialization: "Prostate",
        Degree: "MBBS, MS",
        Mobile: "+1 23 456890",
        Email: "example@email.com",
        JoiningDate: "01.10.2022",
        FIELD9: ""
      },
      {
        id:"7",
        Img:blogimg2,
        Name: "Andrea Lalema",
        Department: "Otolaryngology",
        Specialization: "Infertility",
        Degree: "MBBS, MS",
        Mobile: "+1 23 456890",
        Email: "example@email.com",
        JoiningDate: "01.10.2022",
        FIELD9: ""
      },
      {
        id:"8",
        Img:blogimg4,
        Name: "Dr.Smith Bruklin",
        Department: "Urology",
        Specialization: "Prostate",
        Degree: "MBBS, MS",
        Mobile: "+1 23 456890",
        Email: "example@email.com",
        JoiningDate: "01.10.2022",
        FIELD9: ""
      }
  ]
}