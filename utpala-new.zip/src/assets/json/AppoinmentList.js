import { blogimg10, blogimg12, blogimg2, blogimg4, blogimg6, blogimg8 } from "../../components/imagepath";



export default {
    Data: [
        {   
            id:"1",
            Img:blogimg2,

            FIELD1: "",
            Name: "Andrea Lalema",
            ConsultingDoctor: "Dr.Bernardo James",
            Treatment: "Infertility",
            Mobile: "+1 23 456890",
            Email: "example@email.com",
            Date: "01.10.2022",
            Time: "07:30",
            FIELD9: ""
        },
        {
            id:"2",
            Img:blogimg4,

            
            FIELD1: "",
            Name: "Smith Bruklin",
            ConsultingDoctor: "Dr.William Stephin",
            Treatment: "Infertility",
            Mobile: "+1 23 456890",
            Email: "example@email.com",
            Date: "01.10.2022",
            Time: "07:30",
            FIELD9: ""
        },
        {
            id:"3",
            Img:blogimg6,

            FIELD1: "",
            Name: "William Stephin",
            ConsultingDoctor: "Dr.Galaviz Lalema",
            Treatment: "Cancer",
            Mobile: "+1 23 456890",
            Email: "example@email.com",
            Date: "01.10.2022",
            Time: "07:30",
            FIELD9: ""   
        },
        {
            id:"4",
            Img:blogimg12,

            FIELD1: "",
            Name: "Bernardo James",
            ConsultingDoctor: "Dr.Cristina Groves",
            Treatment: "Infertility",
            Mobile: "+1 23 456890",
            Email: "example@email.com",
            Date: "01.10.2022",
            Time: "07:30",
            FIELD9: " "
        },
        {
            id:"5",
            Img:blogimg10,

            FIELD1: "",
            Name: "Cristina Groves",
            ConsultingDoctor: "Dr.Smith Bruklin",
            Treatment: "Infertility",
            Mobile: "+1 23 456890",
            Email: "example@email.com",
            Date: "01.10.2022",
            Time: "07:30",
            FIELD9: " "
        },
        {
            id:"6",
            Img:blogimg8,

            FIELD1: "",
            Name: "Mark Hay Smith",
            ConsultingDoctor: "Dr.Smith Bruklin",
            Treatment: "Prostate",
            Mobile: "+1 23 456890",
            Email: "example@email.com",
            Date: "01.10.2022",
            Time: "07:30",
            FIELD9: " "
        },
        {
            id:"7",
            Img:blogimg2,

            FIELD1: "",
            Name: "Andrea Lalema",
            ConsultingDoctor: "Dr.Smith Bruklin",
            Treatment: "Infertility",
            Mobile: "+1 23 456890",
            Email: "example@email.com",
            Date: "01.10.2022",
            Time: "07:30",
            FIELD9: " "
        },
        {
            id:"8",
            Img:blogimg4,

            FIELD1: "",
            Name: "Smith Bruklin",
            ConsultingDoctor: "Dr.Bernardo James",
            Treatment: "Infertility",
            Mobile: "+1 23 456890",
            Email: "example@email.com",
            Date: "01.10.2022",
            Time: "07:30",
            FIELD9: " "
        }
    ]
}